<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Corporation;
use App\Models\Question;
use App\Models\SavedFilter;
use App\Models\SimulatedExam;
use App\Models\SimulatedExamQuestion;
use App\Models\Subject;
use App\Models\Topic;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class SimulatedController extends Controller
{
    public function index(): View
    {
        $savedFilter = SavedFilter::query()->where('user_id', Auth::id())->first();
        $simulatedExams = SimulatedExam::query()
            ->where('user_id', Auth::id())
            ->latest('id')
            ->paginate(10);

        return view('student.simulated.index', [
            'savedFilter' => $savedFilter,
            'simulatedExams' => $simulatedExams,
            'corporations' => Corporation::query()->where('active', true)->orderBy('name')->get(),
            'subjects' => Subject::query()->where('active', true)->orderBy('name')->get(),
            'topics' => Topic::query()->where('active', true)->orderBy('name')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'title' => ['nullable', 'string', 'max:180'],
            'corporation_id' => ['nullable', 'integer', 'exists:corporations,id'],
            'subject_id' => ['nullable', 'integer', 'exists:subjects,id'],
            'topic_id' => ['nullable', 'integer', 'exists:topics,id'],
            'difficulty' => ['nullable', 'in:easy,medium,hard'],
            'source_type' => ['nullable', 'string', 'max:30'],
            'quantity' => ['required', 'integer', 'min:1', 'max:200'],
        ]);

        $questions = Question::query()
            ->where('status', 'published')
            ->when(!empty($data['corporation_id']), fn ($q) => $q->where('corporation_id', $data['corporation_id']))
            ->when(!empty($data['subject_id']), fn ($q) => $q->where('subject_id', $data['subject_id']))
            ->when(!empty($data['topic_id']), fn ($q) => $q->where('topic_id', $data['topic_id']))
            ->when(!empty($data['difficulty']), fn ($q) => $q->where('difficulty', $data['difficulty']))
            ->when(!empty($data['source_type']), fn ($q) => $q->where('source_type', $data['source_type']))
            ->inRandomOrder()
            ->limit((int) $data['quantity'])
            ->get(['id']);

        if ($questions->isEmpty()) {
            return back()->withInput()->withErrors([
                'quantity' => 'Nenhuma questão encontrada para montar o simulado.',
            ]);
        }

        $simulatedExam = DB::transaction(function () use ($data, $questions) {
            $simulatedExam = SimulatedExam::query()->create([
                'user_id' => Auth::id(),
                'title' => $data['title'] ?: 'Simulado ' . now()->format('d/m/Y H:i'),
                'corporation_id' => $data['corporation_id'] ?? null,
                'subject_id' => $data['subject_id'] ?? null,
                'topic_id' => $data['topic_id'] ?? null,
                'difficulty' => $data['difficulty'] ?? null,
                'source_type' => $data['source_type'] ?? null,
                'total_questions' => $questions->count(),
                'started_at' => now(),
            ]);

            $rows = [];
            foreach ($questions->values() as $index => $question) {
                $rows[] = [
                    'simulated_exam_id' => $simulatedExam->id,
                    'question_id' => $question->id,
                    'position' => $index + 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }

            SimulatedExamQuestion::query()->insert($rows);

            return $simulatedExam;
        });

        return redirect()->route('student.simulated.show', ['simulatedExam' => $simulatedExam->id]);
    }

    public function show(SimulatedExam $simulatedExam): View|RedirectResponse
    {
        $this->authorizeSimulated($simulatedExam);

        $currentItem = $simulatedExam->items()
            ->whereNull('answered_at')
            ->orderBy('position')
            ->with([
                'question.alternatives',
                'question.subject',
                'question.topic',
                'question.exam',
                'question.corporation',
                'question.comments' => fn ($q) => $q->where('status', 'approved')->latest()->with('user'),
                'question.difficultyVotes',
            ])
            ->first();

        if (!$currentItem) {
            return redirect()->route('student.simulated.result', ['simulatedExam' => $simulatedExam->id]);
        }

        $answeredCount = $simulatedExam->items()->whereNotNull('answered_at')->count();

        return view('student.simulated.show', [
            'simulatedExam' => $simulatedExam,
            'currentItem' => $currentItem,
            'question' => $currentItem->question,
            'currentPosition' => $answeredCount + 1,
            'totalQuestions' => $simulatedExam->total_questions,
        ]);
    }

    public function answer(Request $request, SimulatedExam $simulatedExam): RedirectResponse
    {
        $this->authorizeSimulated($simulatedExam);

        $data = $request->validate([
            'simulated_exam_question_id' => ['required', 'integer', 'exists:simulated_exam_questions,id'],
            'selected_alternative_id' => ['required', 'integer', 'exists:alternatives,id'],
        ]);

        $item = SimulatedExamQuestion::query()
            ->with('question.alternatives')
            ->where('simulated_exam_id', $simulatedExam->id)
            ->findOrFail($data['simulated_exam_question_id']);

        $selectedAlternative = $item->question->alternatives->firstWhere('id', (int) $data['selected_alternative_id']);

        if (!$selectedAlternative) {
            return back()->withErrors([
                'selected_alternative_id' => 'A alternativa selecionada não pertence à questão do simulado.',
            ]);
        }

        $item->update([
            'selected_alternative_id' => $selectedAlternative->id,
            'is_correct' => (bool) $selectedAlternative->is_correct,
            'answered_at' => now(),
        ]);

        $this->refreshResult($simulatedExam);

        return redirect()->route('student.simulated.show', ['simulatedExam' => $simulatedExam->id])
            ->with('status', 'Resposta registrada com sucesso.');
    }

    public function result(SimulatedExam $simulatedExam): View
    {
        $this->authorizeSimulated($simulatedExam);
        $this->refreshResult($simulatedExam);

        $simulatedExam->load([
            'items.question.subject',
            'items.question.topic',
            'items.question.exam',
            'items.selectedAlternative',
        ]);

        return view('student.simulated.result', [
            'simulatedExam' => $simulatedExam,
            'items' => $simulatedExam->items,
        ]);
    }

    private function refreshResult(SimulatedExam $simulatedExam): void
    {
        $total = $simulatedExam->items()->count();
        $correct = $simulatedExam->items()->where('is_correct', true)->count();
        $pending = $simulatedExam->items()->whereNull('answered_at')->count();

        $simulatedExam->update([
            'total_questions' => $total,
            'correct_answers' => $correct,
            'accuracy' => $total > 0 ? round(($correct / $total) * 100, 2) : 0,
            'finished_at' => $pending === 0 ? now() : null,
        ]);
    }

    private function authorizeSimulated(SimulatedExam $simulatedExam): void
    {
        abort_unless((int) $simulatedExam->user_id === (int) Auth::id(), 403);
    }
}
