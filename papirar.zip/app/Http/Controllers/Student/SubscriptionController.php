<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\PaymentTransaction;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Services\Billing\MercadoPagoService;
use App\Services\Billing\SubscriptionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class SubscriptionController extends Controller
{
    public function __construct(
        protected SubscriptionService $subscriptionService,
        protected MercadoPagoService $mercadoPagoService,
    ) {
    }

    public function index(): View
    {
        $user = Auth::user();

        $plans = SubscriptionPlan::query()
            ->where('active', true)
            ->orderBy('price')
            ->get();

        $currentSubscription = Subscription::query()
            ->with('plan')
            ->where('user_id', $user->id)
            ->latest('id')
            ->first();

        return view('student.subscriptions.index', [
            'plans' => $plans,
            'currentSubscription' => $currentSubscription,
        ]);
    }

    public function checkout(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'plan_id' => ['required', 'integer', 'exists:subscription_plans,id'],
        ]);

        $user = Auth::user();
        $plan = SubscriptionPlan::query()
            ->where('active', true)
            ->findOrFail($validated['plan_id']);

        try {
            $subscription = $this->subscriptionService->createPendingSubscription($user, $plan);

            $checkoutData = $this->mercadoPagoService->createCheckoutPreference($user, $plan, $subscription);

            PaymentTransaction::query()->create([
                'user_id' => $user->id,
                'subscription_id' => $subscription->id,
                'gateway' => 'mercado_pago',
                'external_id' => $checkoutData['external_id'] ?? null,
                'amount' => $plan->price,
                'status' => 'pending',
                'payload' => json_encode($checkoutData, JSON_UNESCAPED_UNICODE),
            ]);

            return redirect()->away($checkoutData['checkout_url']);
        } catch (\Throwable $e) {
            Log::error('Erro ao iniciar checkout da assinatura.', [
                'user_id' => $user->id,
                'plan_id' => $plan->id,
                'exception' => $e,
            ]);

            return back()->withInput()->with('error', 'Não foi possível iniciar o pagamento da assinatura.');
        }
    }

    public function history(): View
    {
        $subscriptions = Subscription::query()
            ->with(['plan', 'transactions'])
            ->where('user_id', Auth::id())
            ->latest('id')
            ->paginate(15);

        return view('student.subscriptions.history', [
            'subscriptions' => $subscriptions,
        ]);
    }
}
