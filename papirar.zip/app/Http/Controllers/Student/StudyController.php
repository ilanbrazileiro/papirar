<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Corporation;
use App\Models\Question;
use App\Models\SavedFilter;
use App\Models\StudySession;
use App\Models\StudySessionQuestion;
use App\Models\Subject;
use App\Models\Topic;
use App\Models\UserAnswer;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class StudyController extends Controller
{
    public function index(): View
    {
        $user = Auth::user();
        $savedFilter = SavedFilter::query()->firstOrCreate(
            ['user_id' => $user->id],
            ['quantity' => 10, 'mode' => 'train']
        );

        return view('student.study.index', [
            'corporations' => Corporation::query()->where('active', true)->orderBy('name')->get(),
            'subjects' => Subject::query()->where('active', true)->orderBy('name')->get(),
            'topics' => Topic::query()->where('active', true)->orderBy('name')->get(),
            'savedFilter' => $savedFilter,
        ]);
    }

    public function start(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'corporation_id' => ['nullable', 'integer', 'exists:corporations,id'],
            'subject_id' => ['nullable', 'integer', 'exists:subjects,id'],
            'topic_id' => ['nullable', 'integer', 'exists:topics,id'],
            'difficulty' => ['nullable', 'in:easy,medium,hard'],
            'source_type' => ['nullable', 'string', 'max:30'],
            'quantity' => ['required', 'integer', 'min:1', 'max:200'],
            'mode' => ['required', 'in:train,review,exam'],
        ]);

        $user = Auth::user();

        SavedFilter::query()->updateOrCreate(
            ['user_id' => $user->id],
            [
                'corporation_id' => $data['corporation_id'] ?? null,
                'subject_id' => $data['subject_id'] ?? null,
                'topic_id' => $data['topic_id'] ?? null,
                'difficulty' => $data['difficulty'] ?? null,
                'source_type' => $data['source_type'] ?? null,
                'quantity' => $data['quantity'],
                'mode' => $data['mode'],
            ]
        );

        $questionsQuery = Question::query()
            ->where('status', 'published')
            ->with(['alternatives', 'subject', 'topic', 'exam', 'corporation']);

        if (!empty($data['corporation_id'])) {
            $questionsQuery->where('corporation_id', $data['corporation_id']);
        }

        if (!empty($data['subject_id'])) {
            $questionsQuery->where('subject_id', $data['subject_id']);
        }

        if (!empty($data['topic_id'])) {
            $questionsQuery->where('topic_id', $data['topic_id']);
        }

        if (!empty($data['difficulty'])) {
            $questionsQuery->where('difficulty', $data['difficulty']);
        }

        if (!empty($data['source_type'])) {
            $questionsQuery->where('source_type', $data['source_type']);
        }

        if ($data['mode'] === 'review') {
            $questionsQuery->whereIn('id', function ($subQuery) use ($user) {
                $subQuery->select('question_id')
                    ->from('user_answers')
                    ->where('user_id', $user->id)
                    ->where('is_correct', false);
            });
        }

        $questionIds = $questionsQuery
            ->inRandomOrder()
            ->limit((int) $data['quantity'])
            ->pluck('id');

        if ($questionIds->isEmpty()) {
            return back()->withInput()->withErrors([
                'quantity' => 'Nenhuma questão encontrada com os filtros informados.',
            ]);
        }

        $session = DB::transaction(function () use ($user, $data, $questionIds) {
            $session = StudySession::query()->create([
                'user_id' => $user->id,
                'corporation_id' => $data['corporation_id'] ?? null,
                'subject_id' => $data['subject_id'] ?? null,
                'mode' => $data['mode'],
                'started_at' => now(),
            ]);

            $rows = [];
            foreach ($questionIds->values() as $index => $questionId) {
                $rows[] = [
                    'study_session_id' => $session->id,
                    'question_id' => $questionId,
                    'position' => $index + 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }

            StudySessionQuestion::query()->insert($rows);

            return $session;
        });

        return redirect()->route('student.study.question', ['session' => $session->id]);
    }

    public function showQuestion(StudySession $session): View|RedirectResponse
    {
        $this->authorizeSession($session);

        $current = $session->questions()
            ->whereNull('study_session_questions.answered_at')
            ->orderBy('study_session_questions.position')
            ->first();

        if (!$current) {
            return redirect()->route('student.study.result', ['session' => $session->id]);
        }

        $question = $current;
        $question->load([
            'alternatives',
            'subject',
            'topic',
            'exam',
            'corporation',
            'comments' => fn ($query) => $query->where('status', 'approved')->latest()->with('user'),
            'difficultyVotes',
        ]);

        $answeredCount = $session->questions()->whereNotNull('study_session_questions.answered_at')->count();
        $totalQuestions = $session->questions()->count();
        $userAnswer = UserAnswer::query()
            ->where('user_id', Auth::id())
            ->where('study_session_id', $session->id)
            ->where('question_id', $question->id)
            ->latest('id')
            ->first();

        return view('student.study.question', [
            'session' => $session,
            'question' => $question,
            'currentPosition' => $answeredCount + 1,
            'totalQuestions' => $totalQuestions,
            'userAnswer' => $userAnswer,
        ]);
    }

    public function answer(Request $request, StudySession $session): RedirectResponse
    {
        $this->authorizeSession($session);

        $data = $request->validate([
            'question_id' => ['required', 'integer', 'exists:questions,id'],
            'selected_alternative_id' => ['required', 'integer', 'exists:alternatives,id'],
        ]);

        $question = Question::query()->with('alternatives')->findOrFail($data['question_id']);
        $selectedAlternative = $question->alternatives->firstWhere('id', (int) $data['selected_alternative_id']);

        if (!$selectedAlternative) {
            return back()->withErrors([
                'selected_alternative_id' => 'A alternativa selecionada não pertence à questão informada.',
            ]);
        }

        DB::transaction(function () use ($session, $question, $selectedAlternative) {
            UserAnswer::query()->updateOrCreate(
                [
                    'user_id' => Auth::id(),
                    'question_id' => $question->id,
                    'study_session_id' => $session->id,
                ],
                [
                    'selected_alternative_id' => $selectedAlternative->id,
                    'is_correct' => (bool) $selectedAlternative->is_correct,
                    'answered_at' => now(),
                ]
            );

            StudySessionQuestion::query()
                ->where('study_session_id', $session->id)
                ->where('question_id', $question->id)
                ->update([
                    'answered_at' => now(),
                    'updated_at' => now(),
                ]);
        });

        return redirect()->route('student.study.question', ['session' => $session->id])
            ->with('status', 'Resposta registrada com sucesso.');
    }

    public function next(StudySession $session): RedirectResponse
    {
        $this->authorizeSession($session);

        return redirect()->route('student.study.question', ['session' => $session->id]);
    }

    public function result(StudySession $session): View
    {
        $this->authorizeSession($session);

        if (!$session->finished_at && !$session->questions()->whereNull('study_session_questions.answered_at')->exists()) {
            $session->update(['finished_at' => now()]);
        }

        $answers = UserAnswer::query()
            ->where('user_id', Auth::id())
            ->where('study_session_id', $session->id)
            ->with(['question.subject', 'question.topic', 'question.exam', 'selectedAlternative'])
            ->get();

        $total = $answers->count();
        $correct = $answers->where('is_correct', true)->count();
        $incorrect = $total - $correct;
        $accuracy = $total > 0 ? round(($correct / $total) * 100, 2) : 0;

        return view('student.study.result', [
            'session' => $session,
            'answers' => $answers,
            'total' => $total,
            'correct' => $correct,
            'incorrect' => $incorrect,
            'accuracy' => $accuracy,
        ]);
    }

    private function authorizeSession(StudySession $session): void
    {
        abort_unless((int) $session->user_id === (int) Auth::id(), 403);
    }
}
