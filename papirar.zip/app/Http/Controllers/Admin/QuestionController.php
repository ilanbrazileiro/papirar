<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Alternative;
use App\Models\Corporation;
use App\Models\Exam;
use App\Models\Question;
use App\Models\Subject;
use App\Models\Topic;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QuestionController extends Controller
{
    public function index(Request $request)
    {
        $questions = Question::query()
            ->with(['corporation', 'exam', 'subject', 'topic'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')))
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('admin.questions.index', compact('questions'));
    }

    public function create()
    {
        return view('admin.questions.create', [
            'corporations' => Corporation::orderBy('name')->get(),
            'exams' => Exam::orderByDesc('year')->orderBy('title')->get(),
            'subjects' => Subject::orderBy('name')->get(),
            'topics' => Topic::orderBy('name')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'corporation_id' => ['required', 'integer'],
            'exam_id' => ['nullable', 'integer'],
            'subject_id' => ['required', 'integer'],
            'topic_id' => ['nullable', 'integer'],
            'statement' => ['required', 'string'],
            'question_type' => ['required', 'string', 'max:30'],
            'difficulty' => ['required', 'in:easy,medium,hard'],
            'source_type' => ['required', 'string', 'max:30'],
            'source_reference' => ['nullable', 'string', 'max:255'],
            'commented_answer' => ['nullable', 'string'],
            'status' => ['required', 'in:draft,published,archived'],
            'alternatives' => ['required', 'array', 'min:2'],
            'alternatives.*.letter' => ['required', 'string', 'max:1'],
            'alternatives.*.text' => ['required', 'string'],
            'alternatives.*.is_correct' => ['nullable', 'boolean'],
        ]);

        DB::transaction(function () use ($data) {
            $question = Question::create([
                'corporation_id' => $data['corporation_id'],
                'exam_id' => $data['exam_id'] ?? null,
                'subject_id' => $data['subject_id'],
                'topic_id' => $data['topic_id'] ?? null,
                'statement' => $data['statement'],
                'question_type' => $data['question_type'],
                'difficulty' => $data['difficulty'],
                'source_type' => $data['source_type'],
                'source_reference' => $data['source_reference'] ?? null,
                'commented_answer' => $data['commented_answer'] ?? null,
                'status' => $data['status'],
                'created_by' => auth()->id(),
            ]);

            foreach ($data['alternatives'] as $alternative) {
                $question->alternatives()->create([
                    'letter' => strtoupper($alternative['letter']),
                    'text' => $alternative['text'],
                    'is_correct' => (bool) ($alternative['is_correct'] ?? false),
                ]);
            }
        });

        return redirect()->route('admin.questions.index')->with('success', 'Questão criada com sucesso.');
    }

    public function show(Question $question)
    {
        $question->load(['corporation', 'exam', 'subject', 'topic', 'alternatives']);

        return view('admin.questions.show', compact('question'));
    }

    public function edit(Question $question)
    {
        $question->load('alternatives');

        return view('admin.questions.edit', [
            'question' => $question,
            'corporations' => Corporation::orderBy('name')->get(),
            'exams' => Exam::orderByDesc('year')->orderBy('title')->get(),
            'subjects' => Subject::orderBy('name')->get(),
            'topics' => Topic::orderBy('name')->get(),
        ]);
    }

    public function update(Request $request, Question $question): RedirectResponse
    {
        $data = $request->validate([
            'corporation_id' => ['required', 'integer'],
            'exam_id' => ['nullable', 'integer'],
            'subject_id' => ['required', 'integer'],
            'topic_id' => ['nullable', 'integer'],
            'statement' => ['required', 'string'],
            'question_type' => ['required', 'string', 'max:30'],
            'difficulty' => ['required', 'in:easy,medium,hard'],
            'source_type' => ['required', 'string', 'max:30'],
            'source_reference' => ['nullable', 'string', 'max:255'],
            'commented_answer' => ['nullable', 'string'],
            'status' => ['required', 'in:draft,published,archived'],
            'alternatives' => ['required', 'array', 'min:2'],
            'alternatives.*.letter' => ['required', 'string', 'max:1'],
            'alternatives.*.text' => ['required', 'string'],
            'alternatives.*.is_correct' => ['nullable', 'boolean'],
        ]);

        DB::transaction(function () use ($data, $question) {
            $question->update([
                'corporation_id' => $data['corporation_id'],
                'exam_id' => $data['exam_id'] ?? null,
                'subject_id' => $data['subject_id'],
                'topic_id' => $data['topic_id'] ?? null,
                'statement' => $data['statement'],
                'question_type' => $data['question_type'],
                'difficulty' => $data['difficulty'],
                'source_type' => $data['source_type'],
                'source_reference' => $data['source_reference'] ?? null,
                'commented_answer' => $data['commented_answer'] ?? null,
                'status' => $data['status'],
            ]);

            $question->alternatives()->delete();

            foreach ($data['alternatives'] as $alternative) {
                $question->alternatives()->create([
                    'letter' => strtoupper($alternative['letter']),
                    'text' => $alternative['text'],
                    'is_correct' => (bool) ($alternative['is_correct'] ?? false),
                ]);
            }
        });

        return redirect()->route('admin.questions.edit', $question)->with('success', 'Questão atualizada com sucesso.');
    }

    public function destroy(Question $question): RedirectResponse
    {
        $question->delete();

        return redirect()->route('admin.questions.index')->with('success', 'Questão removida com sucesso.');
    }
}
