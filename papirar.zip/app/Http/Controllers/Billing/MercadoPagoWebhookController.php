<?php

namespace App\Http\Controllers\Billing;

use App\Http\Controllers\Controller;
use App\Services\Billing\MercadoPagoService;
use App\Services\Billing\SubscriptionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class MercadoPagoWebhookController extends Controller
{
    public function __construct(
        protected MercadoPagoService $mercadoPagoService,
        protected SubscriptionService $subscriptionService,
    ) {
    }

    public function handle(Request $request): JsonResponse
    {
        try {
            $payload = $request->all();
            Log::info('Webhook Mercado Pago recebido.', ['payload' => $payload]);

            $paymentData = $this->mercadoPagoService->parseWebhook($payload);

            if (! $paymentData) {
                return response()->json(['message' => 'Evento ignorado.'], 200);
            }

            $this->subscriptionService->processApprovedPayment($paymentData);

            return response()->json(['message' => 'Webhook processado com sucesso.'], 200);
        } catch (\Throwable $e) {
            Log::error('Erro ao processar webhook do Mercado Pago.', [
                'exception' => $e,
                'payload' => $request->all(),
            ]);

            return response()->json(['message' => 'Erro ao processar webhook.'], 500);
        }
    }
}
