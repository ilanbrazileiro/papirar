@extends('layouts.student')

@section('title', 'Resolver questão')

@section('content')
    @php
        $userAnswer = $userAnswer ?? null;
        $answered = !is_null($userAnswer);
        $selectedAlternativeId = $userAnswer->selected_alternative_id ?? null;
        $correctAlternativeId = optional($question->alternatives->firstWhere('is_correct', true))->id;
        $votes = $question->difficultyVotes ?? collect();
        $counts = [
            'easy' => $votes->where('difficulty_vote', 'easy')->count(),
            'medium' => $votes->where('difficulty_vote', 'medium')->count(),
            'hard' => $votes->where('difficulty_vote', 'hard')->count(),
        ];
    @endphp

    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-4">
        <div>
            <h1 class="page-title">Sessão de estudo</h1>
            <div class="d-flex flex-wrap gap-2">
                @if($question->corporation)<span class="meta-badge">{{ $question->corporation->name }}</span>@endif
                @if($question->subject)<span class="meta-badge">{{ $question->subject->name }}</span>@endif
                @if($question->topic)<span class="meta-badge">{{ $question->topic->name }}</span>@endif
                @if($question->exam)<span class="meta-badge">{{ $question->exam->title }}</span>@endif
            </div>
        </div>
        <div class="meta-badge">Questão {{ $currentPosition }} de {{ $totalQuestions }}</div>
    </div>

    <div class="question-card mb-4">
        <div class="fs-5 lh-lg">{!! $question->statement !!}</div>
    </div>

    @if(!$answered)
        <form method="POST" action="{{ route('student.study.answer', $session) }}">
            @csrf
            <input type="hidden" name="question_id" value="{{ $question->id }}">

            <div class="d-grid gap-3">
                @foreach($question->alternatives as $alternative)
                    <label class="alt-card" data-alt-option>
                        <div class="d-flex gap-3">
                            <input class="form-check-input mt-1" type="radio" name="selected_alternative_id" value="{{ $alternative->id }}" required>
                            <div>
                                <div class="fw-semibold mb-1">{{ $alternative->letter }})</div>
                                <div>{!! $alternative->text !!}</div>
                            </div>
                        </div>
                    </label>
                @endforeach
            </div>

            <div class="d-flex justify-content-end mt-4">
                <button class="btn btn-primary btn-lg">Responder</button>
            </div>
        </form>
    @else
        <div class="d-grid gap-3 mb-4">
            @foreach($question->alternatives as $alternative)
                @php
                    $class = '';
                    if ($alternative->id == $correctAlternativeId) $class = 'correct';
                    elseif ($alternative->id == $selectedAlternativeId && !$userAnswer->is_correct) $class = 'wrong';
                @endphp

                <div class="alt-card {{ $class }}">
                    <div class="d-flex gap-3">
                        <input class="form-check-input mt-1" type="radio" disabled @checked($alternative->id == $selectedAlternativeId)>
                        <div>
                            <div class="fw-semibold mb-1">{{ $alternative->letter }})</div>
                            <div>{!! $alternative->text !!}</div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="alert {{ $userAnswer->is_correct ? 'alert-success' : 'alert-danger' }} rounded-4">
            <div class="fw-bold mb-2">{{ $userAnswer->is_correct ? 'Resposta correta.' : 'Resposta incorreta.' }}</div>
            @if($question->commented_answer)
                <div>{!! $question->commented_answer !!}</div>
            @endif
        </div>

        <div class="d-flex justify-content-end mb-4">
            <form method="POST" action="{{ route('student.study.next', $session) }}">
                @csrf
                <button class="btn btn-primary">Próxima questão</button>
            </form>
        </div>
    @endif

    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card-soft p-4">
                <div class="section-title">Classifique a dificuldade</div>
                <form method="POST" action="{{ route('student.questions.difficulty.store', $question) }}">
                    @csrf
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-success text-start" name="difficulty_vote" value="easy">Fácil <span class="float-end">{{ $counts['easy'] }}</span></button>
                        <button class="btn btn-outline-warning text-start" name="difficulty_vote" value="medium">Média <span class="float-end">{{ $counts['medium'] }}</span></button>
                        <button class="btn btn-outline-danger text-start" name="difficulty_vote" value="hard">Difícil <span class="float-end">{{ $counts['hard'] }}</span></button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card-soft p-4">
                <div class="section-title">Enviar comentário</div>
                <form method="POST" action="{{ route('student.questions.comments.store', $question) }}">
                    @csrf
                    <textarea name="comment" rows="5" class="form-control" placeholder="Seu comentário vai para moderação antes de aparecer."></textarea>
                    <button class="btn btn-primary mt-3">Enviar comentário</button>
                </form>
            </div>
        </div>
    </div>

    <div class="card-soft p-4 mt-4">
        <div class="section-title">Comentários aprovados</div>
        <div class="d-grid gap-3">
            @forelse($question->comments as $comment)
                <div class="border rounded-4 p-3">
                    <div class="fw-semibold">{{ $comment->user->name ?? 'Aluno' }}</div>
                    <div class="small-muted mb-2">{{ $comment->created_at?->format('d/m/Y H:i') }}</div>
                    <div>{{ $comment->comment }}</div>
                </div>
            @empty
                <div class="small-muted">Ainda não há comentários aprovados para esta questão.</div>
            @endforelse
        </div>
    </div>
@endsection

@push('scripts')
<script>
document.querySelectorAll('[data-alt-option]').forEach(function (label) {
    label.addEventListener('click', function () {
        document.querySelectorAll('[data-alt-option]').forEach(function (item) {
            item.classList.remove('selected');
        });
        label.classList.add('selected');
        const input = label.querySelector('input[type=radio]');
        if (input) input.checked = true;
    });
});
</script>
@endpush
