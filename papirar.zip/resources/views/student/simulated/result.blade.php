@extends('layouts.student')

@section('title', 'Resultado do simulado')

@section('content')
    <div class="mb-4">
        <h1 class="page-title">Resultado do simulado</h1>
        <p class="page-subtitle">{{ $simulatedExam->title }}</p>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="stats-card">
                <div class="label">Questões</div>
                <div class="value">{{ $simulatedExam->total_questions }}</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <div class="label">Acertos</div>
                <div class="value">{{ $simulatedExam->correct_answers }}</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <div class="label">Acurácia</div>
                <div class="value">{{ number_format((float) $simulatedExam->accuracy, 2, ',', '.') }}%</div>
            </div>
        </div>
    </div>

    <div class="card-soft p-4">
        <div class="section-title">Questões do simulado</div>

        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Disciplina</th>
                        <th>Assunto</th>
                        <th>Prova</th>
                        <th>Resposta</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($items as $item)
                        <tr>
                            <td>{{ $item->position }}</td>
                            <td>{{ $item->question->subject->name ?? '-' }}</td>
                            <td>{{ $item->question->topic->name ?? '-' }}</td>
                            <td>{{ $item->question->exam->title ?? '-' }}</td>
                            <td>
                                @if(is_null($item->answered_at))
                                    <span class="badge text-bg-secondary">Pendente</span>
                                @elseif($item->is_correct)
                                    <span class="badge text-bg-success">Correta</span>
                                @else
                                    <span class="badge text-bg-danger">Errada</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-end mt-4">
            <a href="{{ route('student.simulated.index') }}" class="btn btn-primary">Voltar para simulados</a>
        </div>
    </div>
@endsection
