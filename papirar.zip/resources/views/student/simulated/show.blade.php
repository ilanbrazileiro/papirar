@extends('layouts.student')

@section('title', 'Resolver simulado')

@section('content')
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-4">
        <div>
            <h1 class="page-title">{{ $simulatedExam->title }}</h1>
            <p class="page-subtitle">Questão {{ $currentPosition }} de {{ $totalQuestions }}</p>
        </div>
        <div class="meta-badge">Acurácia atual: {{ number_format((float) $simulatedExam->accuracy, 2, ',', '.') }}%</div>
    </div>

    <div class="question-card mb-4">
        <div class="d-flex flex-wrap gap-2 mb-3">
            @if($question->corporation)<span class="meta-badge">{{ $question->corporation->name }}</span>@endif
            @if($question->subject)<span class="meta-badge">{{ $question->subject->name }}</span>@endif
            @if($question->topic)<span class="meta-badge">{{ $question->topic->name }}</span>@endif
            @if($question->exam)<span class="meta-badge">{{ $question->exam->title }}</span>@endif
        </div>

        <div class="fs-5 lh-lg">{!! $question->statement !!}</div>
    </div>

    <form method="POST" action="{{ route('student.simulated.answer', $simulatedExam) }}">
        @csrf
        <input type="hidden" name="simulated_exam_question_id" value="{{ $currentItem->id }}">

        <div class="d-grid gap-3">
            @foreach($question->alternatives as $alternative)
                <label class="alt-card" data-alt-option>
                    <div class="d-flex gap-3">
                        <input type="radio" class="form-check-input mt-1" name="selected_alternative_id" value="{{ $alternative->id }}" required>
                        <div>
                            <div class="fw-semibold mb-1">{{ $alternative->letter }})</div>
                            <div>{!! $alternative->text !!}</div>
                        </div>
                    </div>
                </label>
            @endforeach
        </div>

        <div class="d-flex justify-content-end mt-4">
            <button class="btn btn-primary btn-lg">Responder e avançar</button>
        </div>
    </form>
@endsection

@push('scripts')
<script>
document.querySelectorAll('[data-alt-option]').forEach(function (label) {
    label.addEventListener('click', function () {
        document.querySelectorAll('[data-alt-option]').forEach(function (item) {
            item.classList.remove('selected');
        });
        label.classList.add('selected');
        const input = label.querySelector('input[type=radio]');
        if (input) input.checked = true;
    });
});
</script>
@endpush
