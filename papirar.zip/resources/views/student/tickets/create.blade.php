@extends('layouts.student')

@section('title', 'Novo ticket')

@section('content')
    <div class="mb-4">
        <h1 class="page-title">Abrir ticket</h1>
        <p class="page-subtitle">Descreva o problema com clareza. Isso reduz ida e volta e acelera o atendimento.</p>
    </div>

    <div class="card-soft p-4 p-md-5">
        <form method="POST" action="{{ route('student.tickets.store') }}">
            @csrf

            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Assunto</label>
                    <input type="text" name="subject" class="form-control" value="{{ old('subject') }}" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Categoria</label>
                    <select name="category" class="form-select" required>
                        <option value="">Selecione</option>
                        <option value="financial" @selected(old('category') === 'financial')>Financeiro</option>
                        <option value="technical" @selected(old('category') === 'technical')>Técnico</option>
                        <option value="question" @selected(old('category') === 'question')>Questão</option>
                        <option value="collaboration" @selected(old('category') === 'collaboration')>Colaboração</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Mensagem inicial</label>
                    <textarea name="message" rows="7" class="form-control" required>{{ old('message') }}</textarea>
                </div>
            </div>

            <div class="d-flex justify-content-end mt-4">
                <button class="btn btn-primary">Enviar ticket</button>
            </div>
        </form>
    </div>
@endsection
