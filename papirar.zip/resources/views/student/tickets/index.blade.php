@extends('layouts.student')

@section('title', 'Meus tickets')

@section('content')
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-4">
        <div>
            <h1 class="page-title">Suporte</h1>
            <p class="page-subtitle">Abra solicitações financeiras, técnicas ou relacionadas a questões.</p>
        </div>
        <a href="{{ route('student.tickets.create') }}" class="btn btn-primary">Novo ticket</a>
    </div>

    <div class="card-soft p-4">
        @if($tickets->count())
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Assunto</th>
                            <th>Categoria</th>
                            <th>Status</th>
                            <th>Última atualização</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($tickets as $ticket)
                            <tr>
                                <td class="fw-semibold">{{ $ticket->subject }}</td>
                                <td>{{ ucfirst($ticket->category) }}</td>
                                <td><span class="badge text-bg-secondary">{{ strtoupper($ticket->status) }}</span></td>
                                <td>{{ $ticket->updated_at?->format('d/m/Y H:i') }}</td>
                                <td class="text-end">
                                    <a href="{{ route('student.tickets.show', $ticket) }}" class="btn btn-sm btn-outline-primary">Abrir</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $tickets->links() }}
            </div>
        @else
            <div class="small-muted">Você ainda não abriu tickets.</div>
        @endif
    </div>
@endsection
