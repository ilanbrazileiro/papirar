@extends('layouts.student')

@section('title', 'Ticket de suporte')

@section('content')
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-4">
        <div>
            <h1 class="page-title">{{ $ticket->subject }}</h1>
            <p class="page-subtitle">Categoria {{ ucfirst($ticket->category) }} · status {{ strtoupper($ticket->status) }}</p>
        </div>
        <a href="{{ route('student.tickets.index') }}" class="btn btn-outline-secondary">Voltar</a>
    </div>

    <div class="card-soft p-4 mb-4">
        <div class="section-title">Conversa</div>

        <div class="d-grid gap-3">
            @foreach($ticket->messages as $message)
                @php
                    $isUser = (int)($message->user_id ?? 0) === (int)auth()->id();
                @endphp
                <div class="d-flex {{ $isUser ? 'justify-content-end' : 'justify-content-start' }}">
                    <div class="ticket-bubble {{ $isUser ? 'ticket-user' : 'ticket-admin' }}">
                        <div class="fw-semibold mb-1">
                            {{ $isUser ? 'Você' : ($message->adminUser->name ?? 'Equipe Papirar') }}
                        </div>
                        <div>{{ $message->message }}</div>
                        <div class="small-muted mt-2">{{ $message->created_at?->format('d/m/Y H:i') }}</div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    @if(!in_array($ticket->status, ['resolved', 'closed']))
        <div class="card-soft p-4">
            <div class="section-title">Responder</div>

            <form method="POST" action="{{ route('student.tickets.reply', $ticket) }}">
                @csrf
                <textarea name="message" rows="5" class="form-control" required>{{ old('message') }}</textarea>

                <div class="d-flex justify-content-end mt-3">
                    <button class="btn btn-primary">Enviar mensagem</button>
                </div>
            </form>
        </div>
    @endif
@endsection
