@extends('admin.layout')

@section('content')
<h2>Tickets</h2>

@foreach($tickets as $ticket)
    <div>
        <a href="/admin/tickets/{{ $ticket->id }}">
            Ticket #{{ $ticket->id }}
        </a>
    </div>
@endforeach
@endsection
