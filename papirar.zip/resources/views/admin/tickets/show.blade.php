@extends('admin.layout')

@section('content')
<h2>Ticket</h2>

@foreach($ticket->messages as $msg)
    <p>{{ $msg->message }}</p>
@endforeach

<form method="POST" action="/admin/tickets/{{ $ticket->id }}/mensagens">
@csrf
<textarea name="message"></textarea>
<button type="submit">Responder</button>
</form>
@endsection
