@extends('admin.layout')

@section('content')
<h2>Dashboard</h2>

<p>Total de Questões: {{ $totalPublishedQuestions }}</p>
<p>Clientes Ativos: {{ $activeCustomers }}</p>
<p>Tickets Abertos: {{ $openTickets }}</p>
@endsection
