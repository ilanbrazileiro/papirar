@extends('admin.layout')

@section('content')
<h2>Criar Questão</h2>

<form method="POST" action="/admin/questions">
@csrf

<textarea name="statement" placeholder="Enunciado"></textarea>

<button type="submit">Salvar</button>
</form>
@endsection
