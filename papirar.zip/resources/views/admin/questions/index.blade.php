@extends('admin.layout')

@section('content')
<h2>Questões</h2>

<a href="/admin/questions/create">Nova Questão</a>

@foreach($questions as $q)
    <div>
        <p>{{ $q->statement }}</p>
        <a href="/admin/questions/{{ $q->id }}/edit">Editar</a>
    </div>
@endforeach
@endsection
