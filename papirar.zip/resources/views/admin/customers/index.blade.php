@extends('admin.layout')

@section('content')
<h2>Clientes</h2>

@foreach($customers as $c)
    <div>{{ $c->name }} - {{ $c->email }}</div>
@endforeach
@endsection
