<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
</head>
<body>
    <h1>Painel Administrativo</h1>
    <nav>
        <a href="/admin/dashboard">Dashboard</a> |
        <a href="/admin/questions">Questões</a> |
        <a href="/admin/customers">Clientes</a> |
        <a href="/admin/tickets">Tickets</a>
    </nav>
    <hr>
    @yield('content')
</body>
</html>
